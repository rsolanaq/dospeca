
const BURGER_IMGS = [
  'https://i.ibb.co/B2CdfmDc/Soberbia.jpg',
  'https://i.ibb.co/HfQHj0vW/ENVIDIA.jpg',
  'https://i.ibb.co/9mzKRmwD/GULA.jpg',
  'https://i.ibb.co/Mqpmjd3/PEREZA.jpg',
  'https://i.ibb.co/gLwtKRLy/7d23ac5f-2383-4354-9b8c-02fbc546d76e.jpg',
  'https://i.ibb.co/jZ9g83t5/El-diavlo-de-Arce.jpg',
  'https://i.ibb.co/TBVZXVkF/f39f6cad-7934-4996-a780-7ae095934948.jpg',
  'https://i.ibb.co/hJM92W3k/Vittorian.jpg',
  'https://i.ibb.co/MDthShxD/La-Pecadora.jpg',
  'https://i.ibb.co/gL2RL7mD/La-diavola.jpg',
  'https://i.ibb.co/W4XbcqQm/El-Bendito.jpg',
  'https://i.ibb.co/tT1d0YgS/La-tentaci-n-trufada.jpg'
];
const neon = ['#D01B1B','#8A0000','#FF2222'];

function ph(idx, label) {
  return `data:image/svg+xml,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="600" height="450"><defs><linearGradient id="g${idx}" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="#1a1010"/><stop offset="100%" stop-color="#0C0C0C"/></linearGradient></defs><rect width="600" height="450" fill="url(#g${idx})"/><rect x="1" y="1" width="598" height="448" fill="none" stroke="rgba(208,27,27,0.12)" stroke-width="1"/><path d="M270 188 h16 l8-13 h12 l8 13 h16 a8 8 0 0 1 8 8 v52 a8 8 0 0 1-8 8 h-60 a8 8 0 0 1-8-8 v-52 a8 8 0 0 1 8-8 z" fill="none" stroke="rgba(208,27,27,0.45)" stroke-width="2.5"/><circle cx="300" cy="222" r="16" fill="none" stroke="rgba(208,27,27,0.45)" stroke-width="2.5"/><text x="300" y="292" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="rgba(255,255,255,0.28)" letter-spacing="5">FOTO PROXIMAMENTE</text><text x="300" y="318" text-anchor="middle" font-family="Arial,sans-serif" font-size="19" fill="rgba(208,27,27,0.5)" letter-spacing="2" font-weight="bold">${label}</text></svg>`)}`;
}

function setImg(el, src, idx, label) {
  if (!el) return;
  el.referrerPolicy = 'no-referrer';
  el.crossOrigin = 'anonymous';
  el.onerror = function () {
    this.onerror = null;
    this.src = ph(idx, label);
  };
  el.src = src;
}

// ── Slider dinámico — rota por todas las burgers con imagen ──────────────
const SLIDER_DATA = [];
document.querySelectorAll('#cat-burgers .burger-tile[data-id]').forEach(tile => {
  const id = +tile.dataset.id;
  if (id > 11) return;
  const src = BURGER_IMGS[id];
  if (!src) return;
  const name = tile.querySelector('.burger-tile-nombre')?.textContent?.trim() || '';
  const tipo = tile.querySelector('.burger-tile-tipo')?.textContent?.trim() || '';
  SLIDER_DATA.push({ id, src, name, tipo });
});

const slideEls  = Array.from(document.querySelectorAll('.foto-slide'));
const slideImgs = ['img1','img2','img3'].map(id => document.getElementById(id));
let sliderIdx = 0;

function setSlide(slideEl, imgEl, burger) {
  imgEl.classList.remove('kb-active');
  imgEl.style.transition = 'opacity 0.45s ease';
  imgEl.style.opacity = '0';
  slideEl.dataset.burgerId = burger.id;
  setTimeout(() => {
    setImg(imgEl, burger.src, burger.id, burger.name);
    const show = () => {
      imgEl.style.transition = 'opacity 0.8s ease';
      void imgEl.offsetWidth;
      imgEl.classList.add('kb-active');
      imgEl.style.opacity = '1';
    };
    imgEl.addEventListener('load',  show, { once: true });
    imgEl.addEventListener('error', show, { once: true });
    const strong = slideEl.querySelector('strong');
    const small  = slideEl.querySelector('small');
    if (strong) strong.textContent = burger.name;
    if (small)  small.textContent  = burger.tipo;
  }, 420);
}

function renderSlider() {
  slideEls.forEach((el, i) => {
    setSlide(el, slideImgs[i], SLIDER_DATA[(sliderIdx + i) % SLIDER_DATA.length]);
  });
}
renderSlider();

let sliderTimer = setInterval(() => {
  sliderIdx = (sliderIdx + 1) % SLIDER_DATA.length;
  renderSlider();
}, 7000);

const sliderWrap = document.getElementById('slider');
sliderWrap.addEventListener('mouseenter', () => clearInterval(sliderTimer));
sliderWrap.addEventListener('mouseleave', () => {
  sliderTimer = setInterval(() => {
    sliderIdx = (sliderIdx + 1) % SLIDER_DATA.length;
    renderSlider();
  }, 7000);
});

// Click → navegar a esa hamburguesa
slideEls.forEach(slide => {
  slide.style.cursor = 'pointer';
  slide.addEventListener('click', () => {
    const id = +slide.dataset.burgerId;
    if (isNaN(id)) return;
    activateTab('burgers');
    document.getElementById('carta').scrollIntoView({ behavior: 'smooth' });
    setTimeout(() => {
      const tile = document.querySelector(`.burger-tile[data-id="${id}"]`);
      if (!tile || !tile.querySelector('.expand-content')) return;
      document.querySelectorAll('.burger-tile.expanded').forEach(t => collapseSwapBack(t));
      expandWithSwap(tile);
      setTimeout(() => {
        const nav  = document.querySelector('nav');
        const tabs = document.querySelector('.carta-tabs');
        const off  = (nav ? nav.offsetHeight : 54) + (tabs ? tabs.offsetHeight : 52) + 10;
        window.scrollBy({ top: tile.getBoundingClientRect().top - off, behavior: 'smooth' });
      }, 80);
    }, 650);
  });
});

// Tiles de burgers
const lbls = ['SOBERBIA','ENVIDIA','GULA','PEREZA','LUJURIA','DIABLO ARCE','AVARICIA','VITTORIAN','PECADORA','LA DIAVOLA','EL BENDITO','TRUFADA'];
for (let i = 0; i < 12; i++) {
  const src = BURGER_IMGS[i];
  setImg(document.getElementById(`t-img${i}`), src, i, lbls[i]);
  setImg(document.getElementById(`e-img${i}`), src, i, lbls[i]);
}

// Tiles de entrantes
const SIDES_IMGS = [
  'https://i.ibb.co/1tqCjPRc/c6933ea9-3bf6-4fe8-86bd-1b8917f97cd1.jpg',
  'https://i.ibb.co/4nzD5nJK/Tiras-De-Pollo.jpg',
  'https://i.ibb.co/nNPkgWfq/Teque-os.jpg',
  'https://i.ibb.co/q3JyRHvt/Rabo-de-Toro.jpg',
  'https://i.ibb.co/67r6mygW/Croquetas-de-queso-azul.jpg',
  'https://i.ibb.co/pj76F4WS/Croquetas-de-BUEY.jpg',
  '',
  'https://i.ibb.co/pryJfNmB/Costilla.jpg',
  'https://i.ibb.co/CK2kgfFZ/Trufa-cheese-fries.jpg',
  'https://i.ibb.co/pBcLmnzq/PULL-PORK-CHEESE-FRIES.jpg',
  'https://i.ibb.co/C574bMX3/Lucas-Fries.jpg',
  '',
  '',
  '',
  ''
];
const sidesLbls = ['ALITAS','TIRAS POLLO','TEQUEÑOS','RABO TORO','QUESO AZUL','BUEY','MIX','COSTILLAS','TRUFA FRIES','PORK FRIES','LUCAS FRIES','MAC CHEESE','MAC PICANTE'];
for (let i = 0; i < 13; i++) {
  setImg(document.getElementById(`s-img${i}`), SIDES_IMGS[i], i, sidesLbls[i]);
  setImg(document.getElementById(`se-img${i}`), SIDES_IMGS[i], i, sidesLbls[i]);
}
setImg(document.getElementById('kids-img0'), '', 0, 'BURGER KIDS');
setImg(document.getElementById('kids-eimg0'), '', 0, 'BURGER KIDS');
setImg(document.getElementById('kids-img1'), '', 1, 'POLLO KIDS');
setImg(document.getElementById('kids-eimg1'), '', 1, 'POLLO KIDS');

// Tiles de ensaladas
const ENS_IMGS = ['https://i.ibb.co/rGZs5Wq5/IMG-8880.jpg', 'https://i.ibb.co/k23yLk6g/7bc1802c-2fe3-4839-b3ba-b0c24c8dd4a3.jpg'];
const ensLbls = ['CÉSAR','4 ESTACIONES'];
for (let i = 0; i < 2; i++) {
  setImg(document.getElementById(`ens-img${i}`), ENS_IMGS[i], i, ensLbls[i]);
  setImg(document.getElementById(`ens-eimg${i}`), ENS_IMGS[i], i, ensLbls[i]);
}

// Tiles de brioches
const BRIOCHE_IMGS = [
  'https://i.ibb.co/bjxkVndD/3e31cce3-8dec-4e6e-a754-25b0d656ddb5.jpg',
  'https://i.ibb.co/tMcqLxgm/d0d101eb-f078-4307-bce4-744cbf44f319.jpg',
  'https://i.ibb.co/LXcTsGbZ/5686e83d-f602-4224-b662-bbdef28ed9d5.jpg'
];
const briLbls = ['PAN NAAN','BRIOCHE CARRILLERA','NAIM AMERICANO'];
for (let i = 0; i < 3; i++) {
  setImg(document.getElementById(`bri-img${i}`), BRIOCHE_IMGS[i], i, briLbls[i]);
  setImg(document.getElementById(`bri-eimg${i}`), BRIOCHE_IMGS[i], i, briLbls[i]);
}

// Fresa Milkshake
const fresaUrl = 'https://i.ibb.co/HDP1xpy8/eec28076-6366-46c2-9fd7-ce88c94181a3.jpg';
setImg(document.getElementById('bat-img1'), fresaUrl, 1, 'FRESA MILKSHAKE');
setImg(document.getElementById('bat-eimg1'), fresaUrl, 1, 'FRESA MILKSHAKE');

// Tiles de postres
const POST_IMGS = [
  'https://i.ibb.co/CK2gysNz/8e2eb5ec-04ab-4db5-a167-4e61f07a9c17.jpg',
  'https://i.ibb.co/FLDLm02d/2b6826d1-37ae-491f-bc8e-f8f7515425d8.jpg'
];
const postLbls = ['COULANT PISTACHO','COULANT LOTUS'];
for (let i = 0; i < 2; i++) {
  setImg(document.getElementById(`post-img${i}`), POST_IMGS[i], i, postLbls[i]);
  setImg(document.getElementById(`post-eimg${i}`), POST_IMGS[i], i, postLbls[i]);
}

// ── Tabs ─────────────────────────────────────────────────────────────────
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', function () {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    this.classList.add('active');
    const cat = this.dataset.cat;
    ['burgers', 'brioches', 'sides', 'ensaladas', 'batidos', 'postres'].forEach(c => {
      document.getElementById(`cat-${c}`).style.display = c === cat ? 'grid' : 'none';
    });
    document.querySelectorAll('.burger-tile.expanded').forEach(t => collapseSwapBack(t));
  });
});

// ── Nota patatas de boniato ──────────────────────────────────────────────
(function injectBoniatoNote() {
  const msg = '🍠 Disponible con batatas — consulta al camarero';
  const inject = tile => {
    const foot = tile.querySelector('.expand-foot');
    if (!foot || foot.previousElementSibling?.classList.contains('boniato-note')) return;
    const p = document.createElement('p');
    p.className = 'boniato-note';
    p.textContent = msg;
    foot.parentNode.insertBefore(p, foot);
  };
  document.querySelectorAll('#cat-burgers .burger-tile').forEach(inject);
  document.querySelectorAll('#cat-sides .boniato-opt').forEach(inject);
})();

// ── Scroll lock: bloquea cualquier scroll durante la manipulación del DOM ─
function withScrollLock(fn) {
  const html = document.documentElement;
  const sy   = window.scrollY;

  // 1. Deshabilita scroll-behavior para que scrollTop sea instantáneo
  html.style.scrollBehavior = 'auto';

  // 2. Captura cualquier evento scroll que el browser intente lanzar y lo cancela
  const snapBack = () => { html.scrollTop = sy; };
  window.addEventListener('scroll', snapBack, true);   // capture phase

  // 3. Ejecuta los cambios de DOM / clases
  fn();

  // 4. Fuerza la posición de forma síncrona, antes de que el browser pinte
  html.scrollTop = sy;

  // 5. Limpia en el siguiente frame y restaura scroll-behavior
  requestAnimationFrame(() => {
    html.scrollTop = sy;
    window.removeEventListener('scroll', snapBack, true);
    html.style.scrollBehavior = '';
  });
}

// ── Grid-swap helpers (evita huecos al expandir tile de columna derecha) ──
function getGridCols(grid) {
  const cols = window.getComputedStyle(grid).gridTemplateColumns.trim().split(/\s+/).length;
  return cols > 0 ? cols : 2;
}
function expandWithSwap(tile) {
  withScrollLock(() => {
    const grid = tile.parentElement;
    if (!grid) return;
    const allTiles = [...grid.querySelectorAll(':scope > .burger-tile')];
    const idx     = allTiles.indexOf(tile);
    if (idx < 0) return;
    const cols   = getGridCols(grid);
    const colPos = idx % cols;
    if (colPos > 0) {
      tile._origNextSib = tile.nextSibling;
      grid.insertBefore(tile, allTiles[idx - colPos]);
      tile._wasSwapped = true;
    }
    tile.classList.add('expanded');
  });
}
function collapseSwapBack(tile) {
  withScrollLock(() => {
    tile.classList.remove('expanded');
    if (tile._wasSwapped) {
      const grid = tile.parentElement;
      if (grid) grid.insertBefore(tile, tile._origNextSib || null);
      tile._wasSwapped = false;
      tile._origNextSib = null;
    }
  });
}

// ── Toggle expand ─────────────────────────────────────────────────────────
document.querySelectorAll('.burger-tile').forEach(tile => {
  tile.addEventListener('click', function (e) {
    if (this.classList.contains('pronto-tile')) return;
    if (e.target.closest('.expand-close')) {
      collapseSwapBack(this);
      return;
    }
    if (e.target.closest('.tile-add') || e.target.closest('.expand-add')) {
      const btn = e.target.closest('button');
      const orig = btn.textContent;
      btn.textContent = '✓';
      setTimeout(() => { btn.textContent = orig; }, 1500);
      return;
    }
    if (!this.querySelector('.expand-content')) return;
    const wasExpanded = this.classList.contains('expanded');
    document.querySelectorAll('.burger-tile.expanded').forEach(t => {
      if (t !== this) collapseSwapBack(t);
    });
    if (wasExpanded) {
      collapseSwapBack(this);
    } else {
      expandWithSwap(this);
    }
  });
});

// ── Slider dots ───────────────────────────────────────────────────────────
const slider = document.getElementById('slider');
const dots = document.querySelectorAll('.dot');
slider.addEventListener('scroll', () => {
  const w = slider.querySelector('.foto-slide').offsetWidth + 10;
  const i = Math.round(slider.scrollLeft / w);
  dots.forEach(d => d.classList.remove('active'));
  if (dots[i]) dots[i].classList.add('active');
}, { passive: true });
dots.forEach(dot => {
  dot.addEventListener('click', () => {
    const i = +dot.dataset.i;
    const w = slider.querySelector('.foto-slide').offsetWidth + 10;
    slider.scrollTo({ left: w * i, behavior: 'smooth' });
  });
});

// ── Smooth scroll ─────────────────────────────────────────────────────────
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const t = document.querySelector(a.getAttribute('href'));
    if (t) { e.preventDefault(); t.scrollIntoView({ behavior: 'smooth' }); }
  });
});

// ── Nav dropdown ──────────────────────────────────────────────────────────
const menuBtn = document.getElementById('menuBtn');
const navDropdown = document.getElementById('navDropdown');

function openMenu() {
  navDropdown.classList.add('open');
  menuBtn.classList.add('open');
  menuBtn.setAttribute('aria-expanded', 'true');
}
function closeMenu() {
  navDropdown.classList.remove('open');
  menuBtn.classList.remove('open');
  menuBtn.setAttribute('aria-expanded', 'false');
}

menuBtn.addEventListener('click', e => {
  e.stopPropagation();
  navDropdown.classList.contains('open') ? closeMenu() : openMenu();
});

document.addEventListener('click', closeMenu);
navDropdown.addEventListener('click', e => e.stopPropagation());

function activateTab(cat) {
  document.querySelectorAll('.tab-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.cat === cat);
  });
  ['burgers', 'brioches', 'sides', 'ensaladas', 'batidos', 'postres'].forEach(c => {
    document.getElementById(`cat-${c}`).style.display = c === cat ? 'grid' : 'none';
  });
  document.querySelectorAll('.burger-tile.expanded').forEach(t => collapseSwapBack(t));
}

// ── Slider drag (mouse) ───────────────────────────────────────────────────
let sliderDragging = false, sliderStartX = 0, sliderScrollLeft = 0;
slider.addEventListener('mousedown', e => {
  sliderDragging = true;
  slider.classList.add('dragging');
  sliderStartX = e.pageX - slider.offsetLeft;
  sliderScrollLeft = slider.scrollLeft;
  e.preventDefault();
});
slider.addEventListener('mouseleave', () => { sliderDragging = false; slider.classList.remove('dragging'); });
slider.addEventListener('mouseup', () => { sliderDragging = false; slider.classList.remove('dragging'); });
slider.addEventListener('mousemove', e => {
  if (!sliderDragging) return;
  e.preventDefault();
  slider.scrollLeft = sliderScrollLeft - (e.pageX - slider.offsetLeft - sliderStartX) * 1.5;
});

navDropdown.querySelectorAll('.nav-drop-item').forEach(item => {
  item.addEventListener('click', () => {
    closeMenu();
    const action = item.dataset.action;
    const carta = document.getElementById('carta');
    carta.scrollIntoView({ behavior: 'smooth' });

    if (action === 'burgers') {
      activateTab('burgers');
    } else if (action === 'brioches') {
      activateTab('brioches');
    } else if (action === 'sides') {
      activateTab('sides');
    } else if (action === 'ensaladas') {
      activateTab('ensaladas');
    } else if (action === 'batidos') {
      activateTab('batidos');
    } else if (action === 'postres') {
      activateTab('postres');
    } else if (action === 'review') {
      document.getElementById('resenas').scrollIntoView({ behavior: 'smooth' });
    } else if (action === 'reto') {
      activateTab('burgers');
      document.getElementById('carta').scrollIntoView({ behavior: 'smooth' });
      setTimeout(() => {
        const reto = document.querySelector('.burger-tile[data-id="12"]');
        if (!reto || !reto.querySelector('.expand-content')) return;
        document.querySelectorAll('.burger-tile.expanded').forEach(t => collapseSwapBack(t));
        expandWithSwap(reto);
        setTimeout(() => {
          const nav  = document.querySelector('nav');
          const tabs = document.querySelector('.carta-tabs');
          const off  = (nav ? nav.offsetHeight : 54) + (tabs ? tabs.offsetHeight : 52) + 10;
          window.scrollBy({ top: reto.getBoundingClientRect().top - off, behavior: 'smooth' });
        }, 80);
      }, 650);
    }
  });
});